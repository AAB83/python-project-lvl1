#!/usr/bin/env python

def main():
    print('Welcom to the Brain Games')

if __name__ == '__main__':
    main()

