#!/usr/bin/env python

from brain_games.games.games_even import main_even


def main():
    main_even()


if __name__ == '__main__':
    main()
