#!/usr/bin/env python

from brain_games.games.games_calc import main_calc


def main():
    main_calc()


if __name__ == '__main__':
    main()
