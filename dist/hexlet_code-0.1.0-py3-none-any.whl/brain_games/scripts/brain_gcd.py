#!/usr/bin/env python

from brain_games.games.games_gcd import main_gcd


def main():
    main_gcd()


if __name__ == '__main__':
    main()
