#!/usr/bin/env python

from brain_games.cli_even import games_even


def main():
    games_even()


if __name__ == '__main__':
    main()
