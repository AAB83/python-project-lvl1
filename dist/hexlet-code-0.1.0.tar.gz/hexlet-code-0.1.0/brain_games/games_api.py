def compare_answer(answer_user, correct_answer):
    if answer_user == correct_answer:
        return True
    else:
        return False


if __name__ == '__main__':
    compare_answer()
